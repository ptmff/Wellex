import { db } from "../connection";

// Helper functions
function randomFromArray<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

function randomDate() {
  const start = new Date(2023, 0, 1).getTime();
  const end = new Date().getTime();
  return new Date(start + Math.random() * (end - start));
}

async function seed() {
  console.log("🌱 Start seeding...");

  // ---- Mock data arrays ----
  const actionTypes = [
    "LOGIN",
    "LOGOUT",
    "CREATE_ORDER",
    "UPDATE_PROFILE",
    "DELETE_ACCOUNT",
  ];

  const users: any[] = [];
  const activities: any[] = [];

  // ---- Generate 50 users ----
  for (let i = 1; i <= 50; i++) {
    users.push({
      id: i,
      email: `user${i}@example.com`,
      name: `Test User ${i}`,
      created_at: randomDate(),
    });
  }

  // ---- Generate 100 activities (2 per user) ----
  let activityId = 1;
  for (let i = 1; i <= 50; i++) {
    for (let j = 0; j < 2; j++) {
      activities.push({
        id: activityId++,
        user_id: i,
        type: randomFromArray(actionTypes),
        payload: JSON.stringify({
          value: Math.floor(Math.random() * 1000),
          success: Math.random() > 0.2,
        }),
        created_at: randomDate(),
      });
    }
  }

  try {
    // ---- Clean tables (order matters because of FK) ----
    console.log("🧹 Cleaning tables...");
    await db("activity").del();
    await db("users").del();

    // ---- Insert users ----
    console.log("👤 Inserting users...");
    await db("users").insert(users);

    // ---- Insert activities ----
    console.log("📊 Inserting activities...");
    await db("activity").insert(activities);

    console.log("✅ Seeding completed successfully!");
    console.log(`Inserted ${users.length} users`);
    console.log(`Inserted ${activities.length} activities`);
  } catch (error) {
    console.error("❌ Seeding failed:", error);
    process.exit(1);
  }
}

seed()
  .then(() => process.exit(0))
  .catch((err) => {
    console.error(err);
    process.exit(1);
  });
